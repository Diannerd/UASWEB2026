const khsRoutes = require('./routes/khs');
app.use('/api/khs', khsRoutes);
